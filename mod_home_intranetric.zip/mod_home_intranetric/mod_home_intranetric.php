<?php
defined( '_JEXEC' ) or die;

echo "Módulo de teste funcionando!";

$hostcrm = 'localhost';
$usercrm = 'root';
$passcrm = 'sejalivre';
$basecrm = 'crmcerne';

//mysql_select_db($basecrm, mysql_connect($hostcrm, $usercrm, $passcrm));


//$sql = 'select * from accounts where account_type="Graduada";';
//$res = mysql_query($sql);

//while($r = mysql_fetch_assoc($res)){
		echo "Teste"
//}



//mysql_select_db("teste", mysql_connect($hostcrm, $usercrm, $passcrm));